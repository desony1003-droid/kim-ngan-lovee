const cover=document.getElementById('cover'),quiz=document.getElementById('quiz'),result=document.getElementById('result'),err=document.getElementById('err');
function show(x){[cover,quiz,result].forEach(e=>e.classList.remove('active'));x.classList.add('active');scrollTo(0,0)}
function showQuiz(){show(quiz)}
function norm(s){return s.toLowerCase().trim().replace(/\s+/g,'').replaceAll('đ','d')}
function check(){let a=norm(document.getElementById('q1').value),b=norm(document.getElementById('q2').value);if(a.includes('banhbeo')&&(b==='10/2'||b==='10-2'||b==='102'||b==='10.2'))show(result);else err.textContent='hình như sai một câu rồi 🥺 thử lại nha'}
