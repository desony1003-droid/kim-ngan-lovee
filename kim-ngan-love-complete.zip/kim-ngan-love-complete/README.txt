KIM NGAN LOVE - HUONG DAN

Cac file:
- index.html
- style.css
- script.js
- images/ (10 anh)

Cau tra loi:
1. minh thích ăn gì? -> bánh bèo
2. minh sinh ngày mấy? -> 10/2

Dua len GitHub:
1. Mo repository.
2. Add file -> Upload files.
3. Tai len 3 file + ca thu muc images.
4. Commit changes.
5. Settings -> Pages.
6. Source: Deploy from a branch.
7. Branch main, folder /(root), Save.
8. Cho GitHub tao link Pages.
